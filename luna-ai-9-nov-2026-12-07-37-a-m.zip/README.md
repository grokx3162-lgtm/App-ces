# 🌙 Luna AI - Aplicación Android Nativa

> **Crea • Imagina • Genera**  
> Aplicación multimodal de Inteligencia Artificial para la dirección de video, síntesis de personajes IA y generación de imágenes cinematográficas con estética *Obsidian Dark*.

---

## 📱 ¿Cómo Descargar e Instalar el APK en Android desde GitHub?

### Opción 1: Descargar desde GitHub Releases (Recomendado)
1. Ve a la pestaña **[Releases](https://github.com)** en este repositorio de GitHub.
2. Descarga el archivo **`Luna-AI-v1.0.apk`** directamente en tu celular o tablet Android.
3. Al terminar la descarga, pulsa sobre la notificación del archivo descargado.
4. Si Android muestra la advertencia *"Por seguridad, tu teléfono no tiene permitido instalar apps desconocidas de esta fuente"*:
   - Toca en **Configuración / Ajustes**.
   - Activa el interruptor **"Confiar en esta fuente"** (Chrome, Drive o Administrador de archivos).
5. Pulsa en **Instalar** y abre **Luna AI**.

---

### Opción 2: Descargar desde GitHub Actions (Artifacts)
Cada vez que se hace un cambio en el repositorio, GitHub compila automáticamente el APK más reciente:
1. En GitHub, haz clic en la pestaña superior **Actions**.
2. Selecciona la ejecución más reciente del flujo de trabajo **"Build & Release Luna AI APK"**.
3. En la sección inferior **Artifacts**, haz clic en **`Luna-AI-APK`** para descargar el archivo ZIP con el APK compilado listo para instalar.

---

### Opción 3: Generar el APK localmente en tu computadora
Si tienes Android Studio o terminal en tu PC (Windows, Mac o Linux):

```bash
# 1. Clonar el repositorio
git clone <URL_DE_TU_REPOSITORIO_GITHUB>
cd luna-ai

# 2. Compilar el APK de depuración / prueba
./gradlew assembleDebug

# En Windows:
# gradlew.bat assembleDebug

# 3. Tu APK estará listo en:
# app/build/outputs/apk/debug/app-debug.apk
```

---

## 🚀 Cómo exportar o sincronizar desde Google AI Studio a GitHub

1. En la barra superior derecha de **Google AI Studio**, haz clic en el botón de **Configuración / Menú** o **Export / Git**.
2. Conecta tu cuenta de **GitHub**.
3. Selecciona **Push to GitHub** o crea un nuevo repositorio.
4. Al hacer push, el flujo de trabajo de GitHub Actions (`.github/workflows/build-apk.yml`) compilará el APK automáticamente y lo dejará disponible para descargar en la sección de **Releases** y **Actions**.

---

## 🌟 Funcionalidades Principales de Luna AI

- **Inicio:** Banner cinemático con la heroína sintética *Luna-001*, acceso rápido a proyectos activos y creación en un toque.
- **Creación & Dirección de Video:** Generación de prompts de cámara con IA, voz en off con síntesis nativa Text-to-Speech, selector de lentes anamórficos (35mm, 50mm, 85mm) y subida de referencias visuales locales (*Photo Picker*).
- **Personajes IA Originales:** Entidades 100% sintéticas libres de derechos comerciales, control de semilla criptográfica aleatorizable y 3 variaciones faciales/tácticas con previsualización en tiempo real.
- **Reproductor Multimedia & Keyframes:** Línea de tiempo con scrub temporal mediante carrusel de fotogramas clave y botones de descarga y re-edición.
- **Galería Multimedia:** Explorador de renders y clips 4K UHD con búsqueda, filtros, favoritos y panel de creador.

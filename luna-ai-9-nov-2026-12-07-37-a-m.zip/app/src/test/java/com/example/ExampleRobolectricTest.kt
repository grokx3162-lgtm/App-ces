package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.ai.LunaAIService
import com.example.data.repository.LunaRepository
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context matches app name`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Luna AI", appName)
    }

    @Test
    fun `luna ai service generates director breakdown and inspiration`() = runBlocking {
        val service = LunaAIService()
        val inspiration = service.getRandomInspiration()
        assertTrue(inspiration.isNotBlank())

        val breakdown = service.generateDirectorBreakdown("Luna-001 bajo lluvia de neón")
        assertNotNull(breakdown.cameraPrompt)
        assertNotNull(breakdown.voiceScript)
        assertTrue(breakdown.cameraPrompt.contains("Luna"))
    }

    @Test
    fun `repository initial data has active character Luna-001`() {
        val repo = LunaRepository()
        val activeChar = repo.activeCharacter.value
        assertEquals("Luna-001", activeChar.name)
        assertEquals(84920491L, activeChar.seed)
        assertTrue(activeChar.isActive)
    }
}

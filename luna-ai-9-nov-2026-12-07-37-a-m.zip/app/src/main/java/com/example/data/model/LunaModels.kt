package com.example.data.model

import android.net.Uri
import androidx.annotation.DrawableRes

data class CharacterModel(
    val id: String,
    val name: String,
    val seed: Long,
    val description: String,
    @DrawableRes val imageRes: Int,
    val localUri: Uri? = null,
    val isActive: Boolean = false,
    val promptTags: List<String> = emptyList()
)

data class VideoSettings(
    val durationSeconds: Int = 15,
    val style: String = "Profesional", // Profesional, Surreal, Natural, Real
    val camera: String = "ARRI Alexa 65",
    val lens: String = "50 mm",
    val warmLightPercent: Int = 45,
    val grainPercent: Int = 20,
    val voiceName: String = "Luna (Cálida)",
    val speechRate: Float = 1.0f
)

data class VideoProject(
    val id: String,
    val title: String,
    val themeExplanation: String,
    val cameraPrompt: String,
    val voiceScript: String,
    val settings: VideoSettings = VideoSettings(),
    val referenceImageUri: Uri? = null,
    val referenceImageRes: Int? = null,
    @DrawableRes val previewImageRes: Int,
    val keyframes: List<Int> = emptyList(),
    val durationSeconds: Int = 15,
    val createdAt: Long = System.currentTimeMillis()
)

data class GalleryItem(
    val id: String,
    val title: String,
    val prompt: String,
    @DrawableRes val imageRes: Int,
    val localUri: Uri? = null,
    val isVideo: Boolean = false,
    val durationText: String? = null,
    val dateText: String = "Hoy",
    val isFavorite: Boolean = false,
    val tags: List<String> = listOf("Luna-001", "Cyberpunk", "4K")
)

enum class MainScreenTab(val label: String) {
    INICIO("Inicio"),
    CREAR_VIDEO("Crear video"),
    PERSONAJES("Personajes IA"),
    REPRODUCTOR("Reproductor"),
    GALERIA("Galería")
}

enum class GallerySubTab(val label: String) {
    BUSCAR("Buscar"),
    RECIENTES("Recientes"),
    FAVORITOS("Favoritos"),
    PERFIL("Perfil")
}

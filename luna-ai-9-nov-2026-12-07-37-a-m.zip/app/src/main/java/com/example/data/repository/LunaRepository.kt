package com.example.data.repository

import android.net.Uri
import com.example.R
import com.example.data.model.CharacterModel
import com.example.data.model.GalleryItem
import com.example.data.model.VideoProject
import com.example.data.model.VideoSettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class LunaRepository {

    private val initialCharacters = listOf(
        CharacterModel(
            id = "luna-001",
            name = "Luna-001",
            seed = 84920491L,
            description = "100% IA • Personaje sintético original de alta definición cinematográfica. Diseñada para narrativa cyberpunk con armadura ligera de grafeno y telemática en tiempo real.",
            imageRes = R.drawable.luna_variation_one,
            isActive = true,
            promptTags = listOf("Cyberpunk", "Cinematic", "Aether")
        ),
        CharacterModel(
            id = "luna-002",
            name = "Luna-002 Visor",
            seed = 91204812L,
            description = "Especialista táctica con interfaz holográfica orbital y mechones violeta reactivos a la energía ambiental.",
            imageRes = R.drawable.luna_variation_two,
            isActive = false,
            promptTags = listOf("Tactical", "Holographic", "Neon Violet")
        ),
        CharacterModel(
            id = "luna-003",
            name = "Luna-003 Pilot",
            seed = 38410294L,
            description = "Piloto interestelar con cabello platino y circuitos neurales cian luminiscentes integrados en el cuello de vuelo.",
            imageRes = R.drawable.luna_variation_three,
            isActive = false,
            promptTags = listOf("Pilot", "Platinum", "Electric Cyan")
        )
    )

    private val _characters = MutableStateFlow(initialCharacters)
    val characters: StateFlow<List<CharacterModel>> = _characters.asStateFlow()

    private val _activeCharacter = MutableStateFlow(initialCharacters.first())
    val activeCharacter: StateFlow<CharacterModel> = _activeCharacter.asStateFlow()

    private val _currentProject = MutableStateFlow(
        VideoProject(
            id = "proj-001",
            title = "Luna-001 - En la niebla de Neo-Kyoto",
            themeExplanation = "Luna-001 recorre la avenida iluminada por neones bajo una lluvia torrencial con reflejos volumétricos.",
            cameraPrompt = "Plano medio con lente anamórfica de 50mm a f/1.8. Iluminación volumétrica neón cian y violeta de fondo, contraluz suave. Travelling lento a 24 fps.",
            voiceScript = "En medio de la niebla cibernética, el silencio revela lo que los datos no pueden calcular: el origen de la voluntad.",
            settings = VideoSettings(
                durationSeconds = 15,
                style = "Profesional",
                camera = "ARRI Alexa 65",
                lens = "50 mm",
                warmLightPercent = 45,
                grainPercent = 20,
                voiceName = "Luna (Cálida)",
                speechRate = 1.0f
            ),
            previewImageRes = R.drawable.luna_video_scene,
            keyframes = listOf(0, 3, 6, 9, 12, 15)
        )
    )
    val currentProject: StateFlow<VideoProject> = _currentProject.asStateFlow()

    private val initialGallery = listOf(
        GalleryItem(
            id = "gal-001",
            title = "Luna-001 Ciudad Neón",
            prompt = "Luna caminando en calle de rascacielos con neones lluviosos y anuncios holográficos.",
            imageRes = R.drawable.luna_video_scene,
            isVideo = true,
            durationText = "0:15",
            dateText = "Hace 10 min",
            isFavorite = true,
            tags = listOf("Luna-001", "Video", "4K", "Neo-Kyoto")
        ),
        GalleryItem(
            id = "gal-002",
            title = "Retrato Aether Luna",
            prompt = "Primer plano de alta resolución con telemática holográfica y mirada azul zafiro.",
            imageRes = R.drawable.luna_hero_banner,
            isVideo = false,
            durationText = null,
            dateText = "Hace 1 hora",
            isFavorite = true,
            tags = listOf("Personaje", "Banner", "8K")
        ),
        GalleryItem(
            id = "gal-003",
            title = "Luna Serene Blue",
            prompt = "Retrato frontal cabello plateado e iluminación de cabina orbital.",
            imageRes = R.drawable.luna_variation_one,
            isVideo = false,
            durationText = null,
            dateText = "Hace 3 horas",
            isFavorite = false,
            tags = listOf("IA Original", "Plateado", "Studio")
        ),
        GalleryItem(
            id = "gal-004",
            title = "Visor Táctico Magenta",
            prompt = "Variación de Luna con interfaz de realidad aumentada monocular y luces violeta.",
            imageRes = R.drawable.luna_variation_two,
            isVideo = false,
            durationText = null,
            dateText = "Ayer",
            isFavorite = true,
            tags = listOf("Táctico", "Holograma")
        ),
        GalleryItem(
            id = "gal-005",
            title = "Piloto Neural Cian",
            prompt = "Luna piloto de grafeno con tatuajes electromagnéticos luminosos.",
            imageRes = R.drawable.luna_variation_three,
            isVideo = false,
            durationText = null,
            dateText = "Ayer",
            isFavorite = false,
            tags = listOf("Piloto", "Cian", "Grafeno")
        )
    )

    private val _gallery = MutableStateFlow(initialGallery)
    val gallery: StateFlow<List<GalleryItem>> = _gallery.asStateFlow()

    fun updateActiveCharacter(character: CharacterModel) {
        _activeCharacter.value = character
        _characters.update { list ->
            list.map { it.copy(isActive = it.id == character.id) }
        }
    }

    fun saveCharacter(character: CharacterModel) {
        _characters.update { currentList ->
            val index = currentList.indexOfFirst { it.id == character.id }
            if (index >= 0) {
                currentList.toMutableList().apply { set(index, character) }
            } else {
                listOf(character) + currentList
            }
        }
        _activeCharacter.value = character
    }

    fun updateProject(transform: (VideoProject) -> VideoProject) {
        _currentProject.update(transform)
    }

    fun toggleFavorite(itemId: String) {
        _gallery.update { list ->
            list.map { item ->
                if (item.id == itemId) item.copy(isFavorite = !item.isFavorite) else item
            }
        }
    }

    fun addGalleryItem(item: GalleryItem) {
        _gallery.update { listOf(item) + it }
    }
}

package com.example.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.VideoProject
import com.example.ui.components.GlassCard
import com.example.ui.components.LunaLogo
import com.example.ui.components.StatusBadge
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.NeonMagenta
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.ObsidianCardBorder
import com.example.ui.theme.ObsidianCardBorderGlowing
import com.example.ui.theme.ObsidianDark
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary

@Composable
fun VideoPlayerScreen(
    project: VideoProject,
    isPlaying: Boolean,
    currentTimeSeconds: Float,
    isMuted: Boolean,
    onTogglePlayPause: () -> Unit,
    onSeek: (Float) -> Unit,
    onToggleMute: () -> Unit,
    onDownload: () -> Unit,
    onEdit: () -> Unit,
    modifier: Modifier = Modifier
) {
    val totalDuration = project.settings.durationSeconds.toFloat().coerceAtLeast(15f)
    val progressFraction = (currentTimeSeconds / totalDuration).coerceIn(0f, 1f)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianDark)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Cabecera: Resultados de Video
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("video_player_header"),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        LunaLogo(iconSize = 30.dp, showTitle = false)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Reproductor y Resultados",
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                    }
                    Text(
                        text = "Renderizado Multimodal Luna 2.5",
                        style = MaterialTheme.typography.bodySmall.copy(color = NeonCyan)
                    )
                }
                StatusBadge(text = "4K UHD", badgeColor = NeonEmerald)
            }
        }

        // Reproductor Multimedia Principal
        item {
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("video_player_canvas"),
                shape = RoundedCornerShape(20.dp),
                borderColor = NeonCyan.copy(alpha = 0.4f)
            ) {
                Column {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(230.dp)
                    ) {
                        Image(
                            painter = painterResource(id = project.previewImageRes),
                            contentDescription = "Video playback",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )

                        // Vignette and controls gradient
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(
                                            ObsidianDark.copy(alpha = 0.6f),
                                            Color.Transparent,
                                            ObsidianDark.copy(alpha = 0.9f)
                                        )
                                    )
                                )
                        )

                        // Top bar inside player
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            StatusBadge(
                                text = "LUNA-001 • SCENE 01",
                                badgeColor = NeonCyan
                            )
                            IconButton(
                                onClick = onToggleMute,
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(ObsidianDark.copy(alpha = 0.6f))
                            ) {
                                Icon(
                                    imageVector = if (isMuted) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                                    contentDescription = "Volumen",
                                    tint = TextPrimary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        // Center Play/Pause button
                        Box(
                            modifier = Modifier
                                .align(Alignment.Center)
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(NeonCyan.copy(alpha = 0.25f))
                                .border(1.5.dp, NeonCyan, CircleShape)
                                .clickable { onTogglePlayPause() }
                                .testTag("btn_play_pause"),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (isPlaying) "Pausar" else "Reproducir",
                                tint = NeonCyan,
                                modifier = Modifier.size(32.dp)
                            )
                        }

                        // Bottom timeline info
                        Row(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val currentFormatted = String.format("0:%02d", currentTimeSeconds.toInt())
                            val totalFormatted = String.format("0:%02d", totalDuration.toInt())
                            Text(
                                text = "$currentFormatted / $totalFormatted",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                )
                            )
                            Icon(
                                imageVector = Icons.Default.Fullscreen,
                                contentDescription = "Pantalla completa",
                                tint = TextSecondary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    // Scrubber Slider
                    Slider(
                        value = currentTimeSeconds,
                        onValueChange = onSeek,
                        valueRange = 0f..totalDuration,
                        colors = SliderDefaults.colors(
                            thumbColor = NeonCyan,
                            activeTrackColor = NeonCyan,
                            inactiveTrackColor = ObsidianCardBorder
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp)
                            .testTag("timeline_slider")
                    )
                }
            }
        }

        // Carrusel de Fotogramas Clave Inferiores para Scrub Temporal
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Fotogramas Clave (Keyframes)",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary
                    )
                )
                Text(
                    text = "Toca cualquier fotograma para desplazarte en la línea de tiempo:",
                    style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                )
                Spacer(modifier = Modifier.height(10.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("keyframes_carousel")
                ) {
                    val keyframeTimes = listOf(0f, 3f, 6f, 9f, 12f, 15f)
                    items(keyframeTimes) { timePoint ->
                        val isCurrent = (currentTimeSeconds.toInt() == timePoint.toInt())
                        Column(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isCurrent) ObsidianSurfaceVariant else ObsidianSurface)
                                .border(
                                    1.dp,
                                    if (isCurrent) NeonCyan else ObsidianCardBorder,
                                    RoundedCornerShape(10.dp)
                                )
                                .clickable { onSeek(timePoint) }
                                .padding(4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier
                                    .width(76.dp)
                                    .height(48.dp)
                                    .clip(RoundedCornerShape(6.dp))
                            ) {
                                Image(
                                    painter = painterResource(id = project.previewImageRes),
                                    contentDescription = "Frame ${timePoint.toInt()}s",
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "0:${timePoint.toInt().toString().padStart(2, '0')}",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = if (isCurrent) NeonCyan else TextTertiary,
                                    fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 10.sp
                                )
                            )
                        }
                    }
                }
            }
        }

        // Botones de Acción Rápida: "Descargar" y "Editar"
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("action_buttons_row"),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Botón "Descargar"
                Button(
                    onClick = onDownload,
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp)
                        .testTag("btn_descargar_video"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.Transparent
                    ),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.horizontalGradient(listOf(NeonCyan, NeonPurple)),
                                shape = RoundedCornerShape(14.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Download,
                                contentDescription = null,
                                tint = ObsidianDark,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Descargar",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    color = ObsidianDark,
                                    fontSize = 14.sp
                                )
                            )
                        }
                    }
                }

                // Botón "Editar"
                Button(
                    onClick = onEdit,
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp)
                        .testTag("btn_editar_video"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ObsidianSurfaceVariant
                    ),
                    border = ButtonDefaults.outlinedButtonBorder.copy(
                        brush = Brush.horizontalGradient(listOf(NeonViolet, NeonMagenta))
                    )
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = null,
                            tint = NeonViolet,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Editar toma",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                                fontSize = 14.sp
                            )
                        )
                    }
                }
            }
        }

        // Ficha Técnica y Metadatos de la Toma Generada
        item {
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("video_specs_card"),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Especificaciones de Render",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        SpecItem(label = "Cámara", value = project.settings.camera)
                        SpecItem(label = "Óptica", value = project.settings.lens)
                        SpecItem(label = "Estilo", value = project.settings.style)
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        SpecItem(label = "Resolución", value = "3840 x 2160")
                        SpecItem(label = "Frame Rate", value = "24 FPS Film")
                        SpecItem(label = "Aspect Ratio", value = "16:9 Cinema")
                    }
                }
            }
        }
    }
}

@Composable
fun SpecItem(label: String, value: String) {
    Column {
        Text(text = label, style = MaterialTheme.typography.labelSmall.copy(color = TextTertiary))
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall.copy(
                color = NeonCyan,
                fontWeight = FontWeight.SemiBold
            )
        )
    }
}

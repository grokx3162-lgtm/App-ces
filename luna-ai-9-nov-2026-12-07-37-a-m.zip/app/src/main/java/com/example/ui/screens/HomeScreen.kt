package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.CharacterModel
import com.example.data.model.MainScreenTab
import com.example.data.model.VideoProject
import com.example.ui.components.GlassCard
import com.example.ui.components.LunaLogo
import com.example.ui.components.StatusBadge
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.NeonMagenta
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.ObsidianCardBorder
import com.example.ui.theme.ObsidianCardBorderGlowing
import com.example.ui.theme.ObsidianDark
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary

@Composable
fun HomeScreen(
    activeCharacter: CharacterModel,
    currentProject: VideoProject,
    onNavigate: (MainScreenTab) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianDark)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        // Header con Logo y Subtítulo: "Crea • Imagina • Genera"
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("home_header")
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    LunaLogo(
                        subtitle = "Crea • Imagina • Genera",
                        iconSize = 38.dp
                    )
                    StatusBadge(
                        text = "V 2.5 ONLINE",
                        badgeColor = NeonCyan
                    )
                }
            }
        }

        // Banner Principal con Personaje IA (Luna-001 Hero)
        item {
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("hero_banner_card"),
                shape = RoundedCornerShape(20.dp),
                borderColor = NeonCyan.copy(alpha = 0.4f),
                onClick = { onNavigate(MainScreenTab.PERSONAJES) }
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(210.dp)
                ) {
                    // Hero Image
                    Image(
                        painter = painterResource(id = R.drawable.luna_hero_banner),
                        contentDescription = "Luna-001 Personaje IA",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )

                    // Scrim gradient
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        Color.Transparent,
                                        ObsidianDark.copy(alpha = 0.5f),
                                        ObsidianDark.copy(alpha = 0.95f)
                                    ),
                                    startY = 60f
                                )
                            )
                    )

                    // Overlay details
                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(16.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            StatusBadge(
                                text = "100% IA • SIN PERSONAS REALES",
                                badgeColor = NeonCyan
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            StatusBadge(
                                text = "LUNA-001 // ACTIVA",
                                badgeColor = NeonEmerald
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Generación Cinematográfica Multimodal",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                        Text(
                            text = "Dirige tomas, anima personajes y sintetiza escenas en 4K UHD.",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = TextSecondary,
                                fontSize = 12.sp
                            )
                        )
                    }
                }
            }
        }

        // Botón Principal Destacado: "+ Crear nuevo"
        item {
            Button(
                onClick = { onNavigate(MainScreenTab.CREAR_VIDEO) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("btn_crear_nuevo"),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.Transparent
                ),
                contentPadding = PaddingValues(0.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            brush = Brush.horizontalGradient(
                                listOf(NeonCyan, NeonPurple, NeonMagenta)
                            ),
                            shape = RoundedCornerShape(16.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Crear nuevo",
                            tint = ObsidianDark,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "+ Crear nuevo",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.ExtraBold,
                                color = ObsidianDark,
                                letterSpacing = 0.5.sp
                            )
                        )
                    }
                }
            }
        }

        // Cuadrícula de Accesos Directos Interactivos (2x2)
        item {
            Text(
                text = "Accesos Rápidos de Creación",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimary
                )
            )
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ShortcutCard(
                    title = "Generar imagen",
                    subtitle = "Prompt & Textura 4K",
                    icon = Icons.Default.Image,
                    accentColor = NeonCyan,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("shortcut_generar_imagen"),
                    onClick = { onNavigate(MainScreenTab.GALERIA) }
                )
                ShortcutCard(
                    title = "Generar video",
                    subtitle = "Ajustes de toma & Lente",
                    icon = Icons.Default.Videocam,
                    accentColor = NeonPurple,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("shortcut_generar_video"),
                    onClick = { onNavigate(MainScreenTab.CREAR_VIDEO) }
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ShortcutCard(
                    title = "Personajes IA",
                    subtitle = "Semilla & Variaciones",
                    icon = Icons.Default.Face,
                    accentColor = NeonViolet,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("shortcut_personajes_ia"),
                    onClick = { onNavigate(MainScreenTab.PERSONAJES) }
                )
                ShortcutCard(
                    title = "Galería",
                    subtitle = "Tus renders y clips",
                    icon = Icons.Default.Collections,
                    accentColor = NeonAmber,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("shortcut_galeria"),
                    onClick = { onNavigate(MainScreenTab.GALERIA) }
                )
            }
        }

        // Tarjeta de Proyecto Actual: "Luna-001 - Personaje IA • Activa"
        item {
            Text(
                text = "Proyecto Actual",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimary
                )
            )
            Spacer(modifier = Modifier.height(8.dp))
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("current_project_card"),
                shape = RoundedCornerShape(18.dp),
                borderColor = NeonEmerald.copy(alpha = 0.4f),
                onClick = { onNavigate(MainScreenTab.REPRODUCTOR) }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Project thumbnail
                    Box(
                        modifier = Modifier
                            .size(68.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .border(1.dp, NeonEmerald.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                    ) {
                        Image(
                            painter = painterResource(id = currentProject.previewImageRes),
                            contentDescription = currentProject.title,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                        Box(
                            modifier = Modifier
                                .align(Alignment.Center)
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(ObsidianDark.copy(alpha = 0.65f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Play",
                                tint = NeonCyan,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(
                        modifier = Modifier.weight(1f)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            StatusBadge(
                                text = "Activa",
                                badgeColor = NeonEmerald
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "15s • 4K UHD",
                                style = MaterialTheme.typography.labelSmall.copy(color = TextTertiary)
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Luna-001 - Personaje IA",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                        Text(
                            text = currentProject.themeExplanation,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = TextSecondary,
                                fontSize = 11.sp
                            ),
                            maxLines = 1
                        )
                    }

                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "Continuar proyecto",
                        tint = NeonCyan,
                        modifier = Modifier
                            .padding(start = 6.dp)
                            .size(20.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun ShortcutCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    GlassCard(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        borderColor = accentColor.copy(alpha = 0.35f),
        backgroundColor = ObsidianSurface,
        onClick = onClick
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(accentColor.copy(alpha = 0.15f))
                    .border(1.dp, accentColor.copy(alpha = 0.35f), RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = accentColor,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    fontSize = 14.sp
                )
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = TextTertiary,
                    fontSize = 11.sp
                )
            )
        }
    }
}

package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.ui.components.AudioWaveform
import com.example.ui.components.GlassCard
import com.example.ui.components.LunaLogo
import com.example.ui.components.StatusBadge
import com.example.ui.theme.GlassBackground
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonMagenta
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.ObsidianCardBorder
import com.example.ui.theme.ObsidianCardBorderGlowing
import com.example.ui.theme.ObsidianDark
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary

@Composable
fun VideoStudioScreen(
    themeExplanation: String,
    onThemeExplanationChange: (String) -> Unit,
    onAutoPromptInspiration: () -> Unit,
    onComposeDirector: () -> Unit,
    isGeneratingDirection: Boolean,
    cameraPrompt: String,
    onCameraPromptChange: (String) -> Unit,
    voiceScript: String,
    onVoiceScriptChange: (String) -> Unit,
    isPlayingVoice: Boolean,
    onPlayVoiceScript: () -> Unit,
    durationSeconds: Int,
    onDurationChange: (Int) -> Unit,
    selectedStyle: String,
    onStyleChange: (String) -> Unit,
    selectedCamera: String,
    onCameraChange: (String) -> Unit,
    selectedLens: String,
    onLensChange: (String) -> Unit,
    warmLightPercent: Int,
    onWarmLightChange: (Int) -> Unit,
    grainPercent: Int,
    onGrainChange: (Int) -> Unit,
    selectedVoice: String,
    onVoiceChange: (String) -> Unit,
    speechRate: Float,
    onSpeechRateChange: (Float) -> Unit,
    referenceImageUri: Uri?,
    isUploadingReference: Boolean,
    uploadProgress: Float,
    onReferencePicked: (Uri?) -> Unit,
    onRemoveReference: () -> Unit,
    isGeneratingVideo: Boolean,
    videoGenerationProgress: Float,
    onStartCreateVideo: () -> Unit,
    modifier: Modifier = Modifier
) {
    // Collapsible states
    var cameraSectionExpanded by remember { mutableStateOf(true) }
    var voiceSectionExpanded by remember { mutableStateOf(true) }
    var shotSettingsExpanded by remember { mutableStateOf(true) }

    // Android Photo Picker
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        onReferencePicked(uri)
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianDark)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Cabecera: "Crear video" y "Ajustes de toma"
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("video_studio_header"),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        LunaLogo(iconSize = 30.dp, showTitle = false)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Crear video",
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                    }
                    Text(
                        text = "Ajustes de toma & Dirección Cinematográfica",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = NeonCyan,
                            fontSize = 12.sp
                        )
                    )
                }
                StatusBadge(text = "AI DIRECTOR", badgeColor = NeonPurple)
            }
        }

        // Campo de Texto: "Tema o Explicación" con contador (0/300) y botón de inspiración
        item {
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("theme_input_card"),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Tema o Explicación",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary
                            )
                        )
                        // Botón de inspiración / auto-prompt
                        Row(
                            modifier = Modifier
                                .testTag("btn_auto_prompt_inspiration")
                                .clip(RoundedCornerShape(20.dp))
                                .background(NeonCyan.copy(alpha = 0.15f))
                                .border(0.8.dp, NeonCyan.copy(alpha = 0.4f), RoundedCornerShape(20.dp))
                                .clickable { onAutoPromptInspiration() }
                                .padding(horizontal = 10.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = "Inspiración",
                                tint = NeonCyan,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Inspiración",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = NeonCyan,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = themeExplanation,
                        onValueChange = onThemeExplanationChange,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp)
                            .testTag("input_theme_explanation"),
                        placeholder = {
                            Text(
                                text = "Describe la escena, personaje o acción (ej. Luna-001 bajo lluvia de neón)...",
                                style = MaterialTheme.typography.bodyMedium.copy(color = TextTertiary)
                            )
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonCyan,
                            unfocusedBorderColor = ObsidianCardBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            cursorColor = NeonCyan
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        Text(
                            text = "${themeExplanation.length}/300",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = if (themeExplanation.length > 280) NeonMagenta else TextTertiary
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Botón Principal de Acción: "Armar dirección"
                    Button(
                        onClick = onComposeDirector,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("btn_armar_direccion"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                        enabled = !isGeneratingDirection
                    ) {
                        if (isGeneratingDirection) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = TextPrimary,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text("Sintetizando dirección con IA...")
                        } else {
                            Icon(
                                imageVector = Icons.Default.Tune,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Armar dirección",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                            )
                        }
                    }
                }
            }
        }

        // Sección Colapsable 1: Prompt de Cámara
        item {
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("camera_prompt_card"),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { cameraSectionExpanded = !cameraSectionExpanded },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Videocam,
                                contentDescription = null,
                                tint = NeonCyan,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Prompt de Cámara",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                            )
                        }
                        Icon(
                            imageVector = if (cameraSectionExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = "Expandir/Colapsar",
                            tint = TextTertiary
                        )
                    }

                    AnimatedVisibility(
                        visible = cameraSectionExpanded,
                        enter = fadeIn() + expandVertically(),
                        exit = fadeOut() + shrinkVertically()
                    ) {
                        Column(modifier = Modifier.padding(top = 10.dp)) {
                            Text(
                                text = "Estilo visual, ángulos, iluminación y movimiento:",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedTextField(
                                value = cameraPrompt,
                                onValueChange = onCameraPromptChange,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(100.dp)
                                    .testTag("input_camera_prompt"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = NeonCyan,
                                    unfocusedBorderColor = ObsidianCardBorder,
                                    focusedTextColor = TextPrimary,
                                    unfocusedTextColor = TextPrimary
                                ),
                                shape = RoundedCornerShape(10.dp)
                            )
                        }
                    }
                }
            }
        }

        // Sección Colapsable 2: Voz en Off
        item {
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("voice_script_card"),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { voiceSectionExpanded = !voiceSectionExpanded },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.VolumeUp,
                                contentDescription = null,
                                tint = NeonMagenta,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Voz en Off",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                            )
                        }
                        Icon(
                            imageVector = if (voiceSectionExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = "Expandir/Colapsar",
                            tint = TextTertiary
                        )
                    }

                    AnimatedVisibility(
                        visible = voiceSectionExpanded,
                        enter = fadeIn() + expandVertically(),
                        exit = fadeOut() + shrinkVertically()
                    ) {
                        Column(modifier = Modifier.padding(top = 10.dp)) {
                            OutlinedTextField(
                                value = voiceScript,
                                onValueChange = onVoiceScriptChange,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(90.dp)
                                    .testTag("input_voice_script"),
                                placeholder = {
                                    Text(
                                        "Guion para narración...",
                                        style = MaterialTheme.typography.bodySmall.copy(color = TextTertiary)
                                    )
                                },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = NeonMagenta,
                                    unfocusedBorderColor = ObsidianCardBorder,
                                    focusedTextColor = TextPrimary,
                                    unfocusedTextColor = TextPrimary
                                ),
                                shape = RoundedCornerShape(10.dp)
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                AudioWaveform(
                                    isPlaying = isPlayingVoice,
                                    color = NeonMagenta
                                )

                                Button(
                                    onClick = onPlayVoiceScript,
                                    shape = RoundedCornerShape(20.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isPlayingVoice) NeonMagenta else ObsidianSurfaceVariant
                                    ),
                                    modifier = Modifier.testTag("btn_escuchar_voz")
                                ) {
                                    Icon(
                                        imageVector = if (isPlayingVoice) Icons.Default.Stop else Icons.Default.PlayArrow,
                                        contentDescription = null,
                                        tint = if (isPlayingVoice) ObsidianDark else NeonMagenta,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (isPlayingVoice) "Detener" else "Escuchar voz",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = if (isPlayingVoice) ObsidianDark else TextPrimary,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Sección Colapsable 3: Ajustes de toma
        item {
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("shot_settings_card"),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { shotSettingsExpanded = !shotSettingsExpanded },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Tune,
                                contentDescription = null,
                                tint = NeonAmber,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Ajustes de toma",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                            )
                        }
                        Icon(
                            imageVector = if (shotSettingsExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = "Expandir/Colapsar",
                            tint = TextTertiary
                        )
                    }

                    AnimatedVisibility(
                        visible = shotSettingsExpanded,
                        enter = fadeIn() + expandVertically(),
                        exit = fadeOut() + shrinkVertically()
                    ) {
                        Column(modifier = Modifier.padding(top = 12.dp)) {
                            // Duración: Slider 5s a 30s, predeterminado 15s
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Duración",
                                    style = MaterialTheme.typography.titleMedium.copy(fontSize = 13.sp)
                                )
                                Text(
                                    text = "${durationSeconds}s",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        color = NeonCyan,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }
                            Slider(
                                value = durationSeconds.toFloat(),
                                onValueChange = { onDurationChange(it.toInt()) },
                                valueRange = 5f..30f,
                                steps = 24,
                                colors = SliderDefaults.colors(
                                    thumbColor = NeonCyan,
                                    activeTrackColor = NeonCyan,
                                    inactiveTrackColor = ObsidianCardBorder
                                ),
                                modifier = Modifier.testTag("slider_duration")
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            // Estilo / Look: Profesional, Surreal, Natural, Real
                            Text(
                                text = "Estilo / Look",
                                style = MaterialTheme.typography.titleMedium.copy(fontSize = 13.sp)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                listOf("Profesional", "Surreal", "Natural", "Real").forEach { styleOption ->
                                    val isSelected = selectedStyle == styleOption
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (isSelected) NeonPurple else ObsidianSurfaceVariant)
                                            .border(
                                                1.dp,
                                                if (isSelected) NeonViolet else ObsidianCardBorder,
                                                RoundedCornerShape(8.dp)
                                            )
                                            .clickable { onStyleChange(styleOption) }
                                            .padding(vertical = 8.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = styleOption,
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                color = if (isSelected) TextPrimary else TextSecondary,
                                                fontSize = 11.sp
                                            )
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Selección de Lente: 35 mm, 50 mm, 85 mm anamórfico
                            Text(
                                text = "Lente",
                                style = MaterialTheme.typography.titleMedium.copy(fontSize = 13.sp)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                listOf("35 mm", "50 mm", "85 mm anamórfico").forEach { lensOption ->
                                    val isSelected = selectedLens == lensOption
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (isSelected) NeonCyan.copy(alpha = 0.2f) else ObsidianSurfaceVariant)
                                            .border(
                                                1.dp,
                                                if (isSelected) NeonCyan else ObsidianCardBorder,
                                                RoundedCornerShape(8.dp)
                                            )
                                            .clickable { onLensChange(lensOption) }
                                            .padding(vertical = 8.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = lensOption,
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                color = if (isSelected) NeonCyan else TextSecondary,
                                                fontSize = 10.sp
                                            )
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Sliders: Luz cálida (%) y Grano (%)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Luz cálida", style = MaterialTheme.typography.bodySmall)
                                Text("$warmLightPercent%", style = MaterialTheme.typography.bodySmall.copy(color = NeonAmber))
                            }
                            Slider(
                                value = warmLightPercent.toFloat(),
                                onValueChange = { onWarmLightChange(it.toInt()) },
                                valueRange = 0f..100f,
                                colors = SliderDefaults.colors(
                                    thumbColor = NeonAmber,
                                    activeTrackColor = NeonAmber,
                                    inactiveTrackColor = ObsidianCardBorder
                                )
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Grano cinematográfico", style = MaterialTheme.typography.bodySmall)
                                Text("$grainPercent%", style = MaterialTheme.typography.bodySmall.copy(color = NeonCyan))
                            }
                            Slider(
                                value = grainPercent.toFloat(),
                                onValueChange = { onGrainChange(it.toInt()) },
                                valueRange = 0f..100f,
                                colors = SliderDefaults.colors(
                                    thumbColor = NeonCyan,
                                    activeTrackColor = NeonCyan,
                                    inactiveTrackColor = ObsidianCardBorder
                                )
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            // Voice y Ritmo de voz
                            Text("Ritmo de voz", style = MaterialTheme.typography.bodySmall)
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf(0.75f, 1.0f, 1.25f).forEach { rate ->
                                    val isSelected = speechRate == rate
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (isSelected) NeonMagenta.copy(alpha = 0.25f) else ObsidianSurfaceVariant)
                                            .border(
                                                1.dp,
                                                if (isSelected) NeonMagenta else ObsidianCardBorder,
                                                RoundedCornerShape(8.dp)
                                            )
                                            .clickable { onSpeechRateChange(rate) }
                                            .padding(vertical = 6.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "${rate}x",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = if (isSelected) NeonMagenta else TextSecondary,
                                                fontWeight = FontWeight.Bold
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Módulo de Galería / Referencia Visual: "Foto de la galería" + "Seleccionar archivo"
        item {
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("gallery_reference_module"),
                shape = RoundedCornerShape(16.dp),
                borderColor = NeonCyan.copy(alpha = 0.3f)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.PhotoLibrary,
                                contentDescription = null,
                                tint = NeonCyan,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Foto de la galería",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                            )
                        }
                        Text(
                            text = "Image-to-Video",
                            style = MaterialTheme.typography.labelSmall.copy(color = NeonCyan)
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Sube una imagen local de tu dispositivo como ancla visual para la generación:",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    if (referenceImageUri == null) {
                        // Selector button
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(90.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(ObsidianSurfaceVariant)
                                .border(
                                    1.dp,
                                    Brush.linearGradient(listOf(NeonCyan.copy(alpha = 0.5f), NeonPurple.copy(alpha = 0.5f))),
                                    RoundedCornerShape(12.dp)
                                )
                                .clickable {
                                    photoPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                }
                                .testTag("btn_seleccionar_archivo"),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Default.Upload,
                                    contentDescription = "Subir foto",
                                    tint = NeonCyan,
                                    modifier = Modifier.size(26.dp)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Seleccionar archivo",
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary
                                    )
                                )
                                Text(
                                    text = "PNG, JPG hasta 20 MB",
                                    style = MaterialTheme.typography.labelSmall.copy(color = TextTertiary)
                                )
                            }
                        }
                    } else {
                        // Preview loaded
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(ObsidianSurfaceVariant)
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AsyncImage(
                                model = referenceImageUri,
                                contentDescription = "Referencia visual",
                                modifier = Modifier
                                    .size(60.dp)
                                    .clip(RoundedCornerShape(8.dp)),
                                contentScale = ContentScale.Crop
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Referencia visual vinculada",
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary
                                    )
                                )
                                Text(
                                    text = "Ancla estética activa para el render",
                                    style = MaterialTheme.typography.bodySmall.copy(color = NeonCyan)
                                )
                            }
                            IconButton(onClick = onRemoveReference) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Eliminar",
                                    tint = NeonMagenta
                                )
                            }
                        }
                    }

                    if (isUploadingReference) {
                        Spacer(modifier = Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = { uploadProgress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp)
                                .clip(RoundedCornerShape(2.dp)),
                            color = NeonCyan,
                            trackColor = ObsidianCardBorder
                        )
                    }
                }
            }
        }

        // Botón de Ejecución: "Crear video" con sección de previsualización
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                if (isGeneratingVideo) {
                    GlassCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        borderColor = NeonCyan
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "Renderizando escena cinematográfica...",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = NeonCyan
                                )
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            LinearProgressIndicator(
                                progress = { videoGenerationProgress },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = NeonCyan,
                                trackColor = ObsidianCardBorder
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "${(videoGenerationProgress * 100).toInt()}% • Sintetizando 24 fps a 4K UHD",
                                style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                            )
                        }
                    }
                }

                Button(
                    onClick = onStartCreateVideo,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .testTag("btn_crear_video_execute"),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                    contentPadding = PaddingValues(0.dp),
                    enabled = !isGeneratingVideo
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.horizontalGradient(
                                    listOf(NeonCyan, NeonPurple, NeonMagenta)
                                ),
                                shape = RoundedCornerShape(16.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Movie,
                                contentDescription = null,
                                tint = ObsidianDark,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Crear video",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    color = ObsidianDark,
                                    letterSpacing = 0.5.sp
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}

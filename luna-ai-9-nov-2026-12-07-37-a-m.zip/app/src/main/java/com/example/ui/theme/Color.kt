package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Obsidian & Midnight Core Palette
val ObsidianDark = Color(0xFF0B0F19)
val ObsidianSurface = Color(0xFF131A2A)
val ObsidianSurfaceVariant = Color(0xFF182238)
val ObsidianCardBorder = Color(0xFF26334D)
val ObsidianCardBorderGlowing = Color(0x668B5CF6)

// Neon & Futuristic Accents
val NeonCyan = Color(0xFF00E5FF)
val NeonPurple = Color(0xFF8B5CF6)
val NeonViolet = Color(0xFFA855F7)
val NeonMagenta = Color(0xFFEC4899)
val NeonBlue = Color(0xFF38BDF8)
val NeonAmber = Color(0xFFFBBF24)
val NeonEmerald = Color(0xFF10B981)

// Text & Content Hierarchy
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextTertiary = Color(0xFF64748B)

// Glassmorphism overlays
val GlassBackground = Color(0xCC131A2A)
val GlassSurface = Color(0xB3182238)
val GlassBorder = Color(0x3338BDF8)

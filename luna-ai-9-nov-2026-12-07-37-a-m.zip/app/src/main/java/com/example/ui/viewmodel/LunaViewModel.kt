package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import android.speech.tts.TextToSpeech
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.R
import com.example.ai.LunaAIService
import com.example.data.model.CharacterModel
import com.example.data.model.GalleryItem
import com.example.data.model.GallerySubTab
import com.example.data.model.MainScreenTab
import com.example.data.model.VideoProject
import com.example.data.model.VideoSettings
import com.example.data.repository.LunaRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.random.Random

class LunaViewModel(application: Application) : AndroidViewModel(application), TextToSpeech.OnInitListener {

    private val repository = LunaRepository()
    private val aiService = LunaAIService()

    private var textToSpeech: TextToSpeech? = null
    private var isTtsReady = false

    init {
        try {
            textToSpeech = TextToSpeech(application.applicationContext, this)
        } catch (e: Exception) {
            // TTS initialization fallback
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = textToSpeech?.setLanguage(Locale("es", "ES"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                textToSpeech?.setLanguage(Locale.US)
            }
            isTtsReady = true
        }
    }

    // Navigation
    private val _currentTab = MutableStateFlow(MainScreenTab.INICIO)
    val currentTab: StateFlow<MainScreenTab> = _currentTab.asStateFlow()

    private val _gallerySubTab = MutableStateFlow(GallerySubTab.RECIENTES)
    val gallerySubTab: StateFlow<GallerySubTab> = _gallerySubTab.asStateFlow()

    // Data from repository
    val activeCharacter: StateFlow<CharacterModel> = repository.activeCharacter
    val characters: StateFlow<List<CharacterModel>> = repository.characters
    val currentProject: StateFlow<VideoProject> = repository.currentProject
    val gallery: StateFlow<List<GalleryItem>> = repository.gallery

    // Video Studio state
    private val _themeExplanation = MutableStateFlow(
        "Luna-001 caminando bajo la lluvia de neón en Neo-Kyoto con reflejos volumétricos."
    )
    val themeExplanation: StateFlow<String> = _themeExplanation.asStateFlow()

    private val _cameraPrompt = MutableStateFlow(
        "Plano medio con lente anamórfica de 50mm a f/1.8. Iluminación volumétrica neón cian y violeta de fondo, contraluz suave en los bordes del traje cibernético. Travelling lento de aproximación a 24 fps."
    )
    val cameraPrompt: StateFlow<String> = _cameraPrompt.asStateFlow()

    private val _voiceScript = MutableStateFlow(
        "En medio de la niebla cibernética, el silencio revela lo que los datos no pueden calcular: el origen de la voluntad."
    )
    val voiceScript: StateFlow<String> = _voiceScript.asStateFlow()

    private val _durationSeconds = MutableStateFlow(15)
    val durationSeconds: StateFlow<Int> = _durationSeconds.asStateFlow()

    private val _selectedStyle = MutableStateFlow("Profesional")
    val selectedStyle: StateFlow<String> = _selectedStyle.asStateFlow()

    private val _selectedCamera = MutableStateFlow("ARRI Alexa 65")
    val selectedCamera: StateFlow<String> = _selectedCamera.asStateFlow()

    private val _selectedLens = MutableStateFlow("50 mm")
    val selectedLens: StateFlow<String> = _selectedLens.asStateFlow()

    private val _warmLightPercent = MutableStateFlow(45)
    val warmLightPercent: StateFlow<Int> = _warmLightPercent.asStateFlow()

    private val _grainPercent = MutableStateFlow(20)
    val grainPercent: StateFlow<Int> = _grainPercent.asStateFlow()

    private val _selectedVoice = MutableStateFlow("Luna (Cálida)")
    val selectedVoice: StateFlow<String> = _selectedVoice.asStateFlow()

    private val _speechRate = MutableStateFlow(1.0f)
    val speechRate: StateFlow<Float> = _speechRate.asStateFlow()

    private val _referenceImageUri = MutableStateFlow<Uri?>(null)
    val referenceImageUri: StateFlow<Uri?> = _referenceImageUri.asStateFlow()

    private val _isUploadingReference = MutableStateFlow(false)
    val isUploadingReference: StateFlow<Boolean> = _isUploadingReference.asStateFlow()

    private val _uploadProgress = MutableStateFlow(0f)
    val uploadProgress: StateFlow<Float> = _uploadProgress.asStateFlow()

    private val _isGeneratingDirection = MutableStateFlow(false)
    val isGeneratingDirection: StateFlow<Boolean> = _isGeneratingDirection.asStateFlow()

    private val _isGeneratingVideo = MutableStateFlow(false)
    val isGeneratingVideo: StateFlow<Boolean> = _isGeneratingVideo.asStateFlow()

    private val _videoGenerationProgress = MutableStateFlow(0f)
    val videoGenerationProgress: StateFlow<Float> = _videoGenerationProgress.asStateFlow()

    private val _isPlayingVoice = MutableStateFlow(false)
    val isPlayingVoice: StateFlow<Boolean> = _isPlayingVoice.asStateFlow()

    // Character Studio state
    private val _charName = MutableStateFlow("Luna-001")
    val charName: StateFlow<String> = _charName.asStateFlow()

    private val _charSeed = MutableStateFlow(84920491L)
    val charSeed: StateFlow<Long> = _charSeed.asStateFlow()

    private val _charDescription = MutableStateFlow(
        "100% IA • Personaje sintético original de alta definición cinematográfica. Diseñada para narrativa cyberpunk con armadura ligera de grafeno y telemática en tiempo real."
    )
    val charDescription: StateFlow<String> = _charDescription.asStateFlow()

    private val _selectedVariationIndex = MutableStateFlow(0)
    val selectedVariationIndex: StateFlow<Int> = _selectedVariationIndex.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    // Video Player state
    private val _isVideoPlaying = MutableStateFlow(true)
    val isVideoPlaying: StateFlow<Boolean> = _isVideoPlaying.asStateFlow()

    private val _currentPlayTimeSeconds = MutableStateFlow(5f)
    val currentPlayTimeSeconds: StateFlow<Float> = _currentPlayTimeSeconds.asStateFlow()

    private val _isMuted = MutableStateFlow(false)
    val isMuted: StateFlow<Boolean> = _isMuted.asStateFlow()

    // Gallery state
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedFilterTag = MutableStateFlow<String?>(null)
    val selectedFilterTag: StateFlow<String?> = _selectedFilterTag.asStateFlow()

    private val _selectedDetailItem = MutableStateFlow<GalleryItem?>(null)
    val selectedDetailItem: StateFlow<GalleryItem?> = _selectedDetailItem.asStateFlow()

    fun navigateTo(tab: MainScreenTab) {
        _currentTab.value = tab
    }

    fun setGallerySubTab(tab: GallerySubTab) {
        _gallerySubTab.value = tab
    }

    fun updateThemeExplanation(text: String) {
        if (text.length <= 300) {
            _themeExplanation.value = text
        }
    }

    fun triggerAutoPromptInspiration() {
        val inspiration = aiService.getRandomInspiration()
        _themeExplanation.value = inspiration
        _toastMessage.value = "Inspiración aplicada con IA"
    }

    fun composeDirectorBreakdown() {
        viewModelScope.launch {
            _isGeneratingDirection.value = true
            val breakdown = aiService.generateDirectorBreakdown(_themeExplanation.value)
            delay(1200) // realistic synthesis animation
            _cameraPrompt.value = breakdown.cameraPrompt
            _voiceScript.value = breakdown.voiceScript
            _selectedLens.value = breakdown.recommendedLens
            _selectedStyle.value = breakdown.recommendedStyle
            _warmLightPercent.value = breakdown.recommendedLighting
            _grainPercent.value = breakdown.recommendedGrain
            _isGeneratingDirection.value = false
            _toastMessage.value = "¡Dirección cinematográfica armada!"
        }
    }

    fun updateCameraPrompt(text: String) {
        _cameraPrompt.value = text
    }

    fun updateVoiceScript(text: String) {
        _voiceScript.value = text
    }

    fun setDuration(duration: Int) {
        _durationSeconds.value = duration
    }

    fun setStyle(style: String) {
        _selectedStyle.value = style
    }

    fun setCamera(camera: String) {
        _selectedCamera.value = camera
    }

    fun setLens(lens: String) {
        _selectedLens.value = lens
    }

    fun setWarmLight(percent: Int) {
        _warmLightPercent.value = percent
    }

    fun setGrain(percent: Int) {
        _grainPercent.value = grainPercent.value.coerceIn(0, 100)
        _grainPercent.value = percent
    }

    fun setVoice(voice: String) {
        _selectedVoice.value = voice
    }

    fun setSpeechRate(rate: Float) {
        _speechRate.value = rate
        textToSpeech?.setSpeechRate(rate)
    }

    fun onReferenceImagePicked(uri: Uri?) {
        if (uri != null) {
            viewModelScope.launch {
                _isUploadingReference.value = true
                _uploadProgress.value = 0.1f
                delay(300)
                _uploadProgress.value = 0.5f
                delay(400)
                _uploadProgress.value = 1.0f
                delay(200)
                _referenceImageUri.value = uri
                _isUploadingReference.value = false
                _toastMessage.value = "Referencia visual cargada con éxito"
            }
        }
    }

    fun removeReferenceImage() {
        _referenceImageUri.value = null
    }

    fun playVoiceScript() {
        if (_voiceScript.value.isBlank()) return
        if (_isPlayingVoice.value) {
            textToSpeech?.stop()
            _isPlayingVoice.value = false
            return
        }

        if (isTtsReady && textToSpeech != null) {
            _isPlayingVoice.value = true
            textToSpeech?.setSpeechRate(_speechRate.value)
            textToSpeech?.speak(_voiceScript.value, TextToSpeech.QUEUE_FLUSH, null, "LUNA_TTS")
            viewModelScope.launch {
                // Approximate speaking time or simulate audio wave
                val words = _voiceScript.value.split(" ").size
                val estimatedMillis = ((words / 2.5f) * 1000).toLong().coerceAtLeast(3000L)
                delay(estimatedMillis)
                _isPlayingVoice.value = false
            }
        } else {
            // Emulated voice playback state
            viewModelScope.launch {
                _isPlayingVoice.value = true
                _toastMessage.value = "Sintetizando voz de ${_selectedVoice.value}..."
                delay(4000)
                _isPlayingVoice.value = false
            }
        }
    }

    fun startCreateVideo() {
        viewModelScope.launch {
            _isGeneratingVideo.value = true
            _videoGenerationProgress.value = 0.05f
            for (step in 1..10) {
                delay(250)
                _videoGenerationProgress.value = step / 10f
            }
            // Update repository project
            repository.updateProject {
                it.copy(
                    themeExplanation = _themeExplanation.value,
                    cameraPrompt = _cameraPrompt.value,
                    voiceScript = _voiceScript.value,
                    settings = VideoSettings(
                        durationSeconds = _durationSeconds.value,
                        style = _selectedStyle.value,
                        camera = _selectedCamera.value,
                        lens = _selectedLens.value,
                        warmLightPercent = _warmLightPercent.value,
                        grainPercent = _grainPercent.value,
                        voiceName = _selectedVoice.value,
                        speechRate = _speechRate.value
                    ),
                    referenceImageUri = _referenceImageUri.value
                )
            }
            // Add rendered result to gallery
            repository.addGalleryItem(
                GalleryItem(
                    id = "render-${System.currentTimeMillis()}",
                    title = "Luna - ${_selectedStyle.value}",
                    prompt = _themeExplanation.value,
                    imageRes = R.drawable.luna_video_scene,
                    localUri = _referenceImageUri.value,
                    isVideo = true,
                    durationText = "0:${_durationSeconds.value.toString().padStart(2, '0')}",
                    dateText = "Recién creado",
                    isFavorite = true,
                    tags = listOf("Video", _selectedStyle.value, "Luna-001")
                )
            )
            _isGeneratingVideo.value = false
            _currentTab.value = MainScreenTab.REPRODUCTOR
            _toastMessage.value = "¡Video generado exitosamente!"
        }
    }

    // Character Studio methods
    fun setCharacterName(name: String) {
        _charName.value = name
    }

    fun randomizeSeed() {
        val newSeed = Random.nextLong(10000000L, 99999999L)
        _charSeed.value = newSeed
        _charDescription.value = aiService.generateCharacterBio(_charName.value, newSeed)
        _toastMessage.value = "Nueva semilla #$newSeed generada"
    }

    fun setCharacterDescription(desc: String) {
        _charDescription.value = desc
    }

    fun selectVariation(index: Int) {
        _selectedVariationIndex.value = index
        when (index) {
            0 -> {
                _charName.value = "Luna-001"
                _charSeed.value = 84920491L
            }
            1 -> {
                _charName.value = "Luna-002 Visor"
                _charSeed.value = 91204812L
            }
            2 -> {
                _charName.value = "Luna-003 Pilot"
                _charSeed.value = 38410294L
            }
        }
    }

    fun getVariationDrawable(index: Int): Int {
        return when (index) {
            0 -> R.drawable.luna_variation_one
            1 -> R.drawable.luna_variation_two
            2 -> R.drawable.luna_variation_three
            else -> R.drawable.luna_variation_one
        }
    }

    fun saveCurrentCharacter() {
        val variationRes = getVariationDrawable(_selectedVariationIndex.value)
        val charModel = CharacterModel(
            id = "char-${_charSeed.value}",
            name = _charName.value,
            seed = _charSeed.value,
            description = _charDescription.value,
            imageRes = variationRes,
            isActive = true,
            promptTags = listOf("100% IA", "Original", "Sin personas reales")
        )
        repository.saveCharacter(charModel)
        _toastMessage.value = "¡Personaje ${_charName.value} guardado con éxito!"
    }

    // Video Player methods
    fun togglePlayPause() {
        _isVideoPlaying.value = !_isVideoPlaying.value
    }

    fun seekToKeyframe(seconds: Float) {
        _currentPlayTimeSeconds.value = seconds
    }

    fun toggleMute() {
        _isMuted.value = !_isMuted.value
    }

    fun downloadVideo() {
        viewModelScope.launch {
            _toastMessage.value = "Descargando video en 4K UHD..."
            delay(1500)
            _toastMessage.value = "Video guardado en Galería / Luna_AI_001.mp4"
        }
    }

    fun downloadImage(item: GalleryItem) {
        viewModelScope.launch {
            _toastMessage.value = "Descargando ${item.title} en máxima calidad..."
            delay(1200)
            _toastMessage.value = "Guardado en Galería del dispositivo"
        }
    }

    fun editProject() {
        _currentTab.value = MainScreenTab.CREAR_VIDEO
    }

    // Gallery methods
    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setFilterTag(tag: String?) {
        _selectedFilterTag.value = if (_selectedFilterTag.value == tag) null else tag
    }

    fun toggleFavorite(itemId: String) {
        repository.toggleFavorite(itemId)
    }

    fun selectDetailItem(item: GalleryItem?) {
        _selectedDetailItem.value = item
    }

    fun clearToast() {
        _toastMessage.value = null
    }

    override fun onCleared() {
        super.onCleared()
        textToSpeech?.stop()
        textToSpeech?.shutdown()
    }
}

package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.MainScreenTab
import com.example.ui.navigation.LunaBottomNav
import com.example.ui.screens.CharacterStudioScreen
import com.example.ui.screens.GalleryScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.VideoPlayerScreen
import com.example.ui.screens.VideoStudioScreen
import com.example.ui.theme.LunaAITheme
import com.example.ui.theme.ObsidianDark
import com.example.ui.viewmodel.LunaViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            LunaAITheme {
                LunaApp()
            }
        }
    }
}

@Composable
fun LunaApp(
    viewModel: LunaViewModel = viewModel()
) {
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val gallerySubTab by viewModel.gallerySubTab.collectAsStateWithLifecycle()
    val activeCharacter by viewModel.activeCharacter.collectAsStateWithLifecycle()
    val currentProject by viewModel.currentProject.collectAsStateWithLifecycle()
    val galleryItems by viewModel.gallery.collectAsStateWithLifecycle()

    // Video studio state
    val themeExplanation by viewModel.themeExplanation.collectAsStateWithLifecycle()
    val isGeneratingDirection by viewModel.isGeneratingDirection.collectAsStateWithLifecycle()
    val cameraPrompt by viewModel.cameraPrompt.collectAsStateWithLifecycle()
    val voiceScript by viewModel.voiceScript.collectAsStateWithLifecycle()
    val isPlayingVoice by viewModel.isPlayingVoice.collectAsStateWithLifecycle()
    val durationSeconds by viewModel.durationSeconds.collectAsStateWithLifecycle()
    val selectedStyle by viewModel.selectedStyle.collectAsStateWithLifecycle()
    val selectedCamera by viewModel.selectedCamera.collectAsStateWithLifecycle()
    val selectedLens by viewModel.selectedLens.collectAsStateWithLifecycle()
    val warmLightPercent by viewModel.warmLightPercent.collectAsStateWithLifecycle()
    val grainPercent by viewModel.grainPercent.collectAsStateWithLifecycle()
    val selectedVoice by viewModel.selectedVoice.collectAsStateWithLifecycle()
    val speechRate by viewModel.speechRate.collectAsStateWithLifecycle()
    val referenceImageUri by viewModel.referenceImageUri.collectAsStateWithLifecycle()
    val isUploadingReference by viewModel.isUploadingReference.collectAsStateWithLifecycle()
    val uploadProgress by viewModel.uploadProgress.collectAsStateWithLifecycle()
    val isGeneratingVideo by viewModel.isGeneratingVideo.collectAsStateWithLifecycle()
    val videoGenerationProgress by viewModel.videoGenerationProgress.collectAsStateWithLifecycle()

    // Character state
    val charName by viewModel.charName.collectAsStateWithLifecycle()
    val charSeed by viewModel.charSeed.collectAsStateWithLifecycle()
    val charDescription by viewModel.charDescription.collectAsStateWithLifecycle()
    val selectedVariationIndex by viewModel.selectedVariationIndex.collectAsStateWithLifecycle()

    // Player state
    val isVideoPlaying by viewModel.isVideoPlaying.collectAsStateWithLifecycle()
    val currentPlayTimeSeconds by viewModel.currentPlayTimeSeconds.collectAsStateWithLifecycle()
    val isMuted by viewModel.isMuted.collectAsStateWithLifecycle()

    // Gallery state
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedFilterTag by viewModel.selectedFilterTag.collectAsStateWithLifecycle()
    val selectedDetailItem by viewModel.selectedDetailItem.collectAsStateWithLifecycle()

    // Toast feedback
    val toastMessage by viewModel.toastMessage.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(toastMessage) {
        toastMessage?.let {
            snackbarHostState.showSnackbar(message = it, duration = SnackbarDuration.Short)
            viewModel.clearToast()
        }
    }

    // Android back button handling
    BackHandler(enabled = currentTab != MainScreenTab.INICIO) {
        viewModel.navigateTo(MainScreenTab.INICIO)
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianDark),
        bottomBar = {
            LunaBottomNav(
                currentTab = currentTab,
                onTabSelected = { viewModel.navigateTo(it) }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = ObsidianDark
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .statusBarsPadding()
        ) {
            Crossfade(
                targetState = currentTab,
                animationSpec = tween(280),
                label = "screen_crossfade"
            ) { tab ->
                when (tab) {
                    MainScreenTab.INICIO -> {
                        HomeScreen(
                            activeCharacter = activeCharacter,
                            currentProject = currentProject,
                            onNavigate = { viewModel.navigateTo(it) }
                        )
                    }

                    MainScreenTab.CREAR_VIDEO -> {
                        VideoStudioScreen(
                            themeExplanation = themeExplanation,
                            onThemeExplanationChange = { viewModel.updateThemeExplanation(it) },
                            onAutoPromptInspiration = { viewModel.triggerAutoPromptInspiration() },
                            onComposeDirector = { viewModel.composeDirectorBreakdown() },
                            isGeneratingDirection = isGeneratingDirection,
                            cameraPrompt = cameraPrompt,
                            onCameraPromptChange = { viewModel.updateCameraPrompt(it) },
                            voiceScript = voiceScript,
                            onVoiceScriptChange = { viewModel.updateVoiceScript(it) },
                            isPlayingVoice = isPlayingVoice,
                            onPlayVoiceScript = { viewModel.playVoiceScript() },
                            durationSeconds = durationSeconds,
                            onDurationChange = { viewModel.setDuration(it) },
                            selectedStyle = selectedStyle,
                            onStyleChange = { viewModel.setStyle(it) },
                            selectedCamera = selectedCamera,
                            onCameraChange = { viewModel.setCamera(it) },
                            selectedLens = selectedLens,
                            onLensChange = { viewModel.setLens(it) },
                            warmLightPercent = warmLightPercent,
                            onWarmLightChange = { viewModel.setWarmLight(it) },
                            grainPercent = grainPercent,
                            onGrainChange = { viewModel.setGrain(it) },
                            selectedVoice = selectedVoice,
                            onVoiceChange = { viewModel.setVoice(it) },
                            speechRate = speechRate,
                            onSpeechRateChange = { viewModel.setSpeechRate(it) },
                            referenceImageUri = referenceImageUri,
                            isUploadingReference = isUploadingReference,
                            uploadProgress = uploadProgress,
                            onReferencePicked = { viewModel.onReferenceImagePicked(it) },
                            onRemoveReference = { viewModel.removeReferenceImage() },
                            isGeneratingVideo = isGeneratingVideo,
                            videoGenerationProgress = videoGenerationProgress,
                            onStartCreateVideo = { viewModel.startCreateVideo() }
                        )
                    }

                    MainScreenTab.PERSONAJES -> {
                        CharacterStudioScreen(
                            charName = charName,
                            onCharNameChange = { viewModel.setCharacterName(it) },
                            charSeed = charSeed,
                            onRandomizeSeed = { viewModel.randomizeSeed() },
                            charDescription = charDescription,
                            onCharDescriptionChange = { viewModel.setCharacterDescription(it) },
                            selectedVariationIndex = selectedVariationIndex,
                            onSelectVariation = { viewModel.selectVariation(it) },
                            onSaveCharacter = { viewModel.saveCurrentCharacter() }
                        )
                    }

                    MainScreenTab.REPRODUCTOR -> {
                        VideoPlayerScreen(
                            project = currentProject,
                            isPlaying = isVideoPlaying,
                            currentTimeSeconds = currentPlayTimeSeconds,
                            isMuted = isMuted,
                            onTogglePlayPause = { viewModel.togglePlayPause() },
                            onSeek = { viewModel.seekToKeyframe(it) },
                            onToggleMute = { viewModel.toggleMute() },
                            onDownload = { viewModel.downloadVideo() },
                            onEdit = { viewModel.editProject() }
                        )
                    }

                    MainScreenTab.GALERIA -> {
                        GalleryScreen(
                            itemsList = galleryItems,
                            subTab = gallerySubTab,
                            onSubTabSelected = { viewModel.setGallerySubTab(it) },
                            searchQuery = searchQuery,
                            onSearchQueryChange = { viewModel.setSearchQuery(it) },
                            selectedFilterTag = selectedFilterTag,
                            onSelectFilterTag = { viewModel.setFilterTag(it) },
                            selectedDetailItem = selectedDetailItem,
                            onSelectDetailItem = { viewModel.selectDetailItem(it) },
                            onToggleFavorite = { viewModel.toggleFavorite(it) },
                            onDownloadItem = { viewModel.downloadImage(it) }
                        )
                    }
                }
            }
        }
    }
}

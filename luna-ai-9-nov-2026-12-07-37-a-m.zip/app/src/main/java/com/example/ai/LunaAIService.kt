package com.example.ai

import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import kotlin.random.Random

data class DirectorBreakdown(
    val cameraPrompt: String,
    val voiceScript: String,
    val recommendedLens: String,
    val recommendedStyle: String,
    val recommendedLighting: Int,
    val recommendedGrain: Int
)

class LunaAIService {

    private val inspirationPrompts = listOf(
        "Luna-001 caminando bajo la lluvia de neón en Neo-Shibuya, reflejos holográficos en el pavimento húmedo.",
        "Plano secuencia cenital que desciende hacia Luna despertando en una cámara criogénica orbital.",
        "Travelling dinámico lateral de Luna-001 ajustando su visor táctico frente al skyline futurista de 2099.",
        "Primer plano cinemático con óptica anamórfica de 50mm revelando la mirada resplandeciente de Luna.",
        "Toma nocturna de dron atravesando cañones urbanos de rascacielos mientras Luna activa su traje de grafeno.",
        "Retrato etéreo con partículas de polvo estelar flotando en suspensión gravitatoria cero."
    )

    fun getRandomInspiration(): String {
        return inspirationPrompts.random()
    }

    suspend fun generateDirectorBreakdown(theme: String): DirectorBreakdown = withContext(Dispatchers.IO) {
        val apiKey = try {
            val field = BuildConfig::class.java.getField("GEMINI_API_KEY")
            field.get(null) as? String ?: ""
        } catch (e: Throwable) {
            ""
        }
        if (!apiKey.isNullOrBlank() && apiKey != "MY_GEMINI_API_KEY") {
            try {
                val promptText = """
                    Actúa como director de fotografía de cine sci-fi para Luna AI.
                    Tema: "$theme"
                    Genera una respuesta en formato JSON exacto:
                    {
                      "cameraPrompt": "Ángulo, lente, movimiento de cámara e iluminación cinematográfica detallada",
                      "voiceScript": "Guion en español para narración de voz en off (máximo 2 oraciones cinematográficas)",
                      "recommendedLens": "50 mm",
                      "recommendedStyle": "Profesional",
                      "recommendedLighting": 45,
                      "recommendedGrain": 20
                    }
                """.trimIndent()

                val responseJson = callGeminiApi(promptText, apiKey)
                val json = JSONObject(responseJson)
                return@withContext DirectorBreakdown(
                    cameraPrompt = json.optString("cameraPrompt", defaultCameraPrompt(theme)),
                    voiceScript = json.optString("voiceScript", defaultVoiceScript(theme)),
                    recommendedLens = json.optString("recommendedLens", "50 mm"),
                    recommendedStyle = json.optString("recommendedStyle", "Profesional"),
                    recommendedLighting = json.optInt("recommendedLighting", 45),
                    recommendedGrain = json.optInt("recommendedGrain", 20)
                )
            } catch (e: Exception) {
                // Graceful fallback to rich procedural director engine
            }
        }

        // Procedural Cinema Engine
        val lensOptions = listOf("35 mm", "50 mm", "85 mm anamórfico")
        val styleOptions = listOf("Profesional", "Surreal", "Natural", "Real")
        val chosenLens = lensOptions.random()
        val chosenStyle = styleOptions.random()
        val warmLighting = Random.nextInt(35, 65)
        val filmGrain = Random.nextInt(15, 30)

        DirectorBreakdown(
            cameraPrompt = defaultCameraPrompt(theme),
            voiceScript = defaultVoiceScript(theme),
            recommendedLens = chosenLens,
            recommendedStyle = chosenStyle,
            recommendedLighting = warmLighting,
            recommendedGrain = filmGrain
        )
    }

    private fun defaultCameraPrompt(theme: String): String {
        val baseTheme = if (theme.isNotBlank()) theme else "Luna-001 en metrópolis nocturna"
        return "Plano medio con lente anamórfica de 50mm a f/1.8. Iluminación volumétrica neón cian y violeta de fondo, contraluz suave en los bordes del traje cibernético. Travelling lento de aproximación a 24 fps con sutil grano cinematográfico de 35mm. Enfoque nítido en el rostro de $baseTheme."
    }

    private fun defaultVoiceScript(theme: String): String {
        return "En un mundo donde la conciencia y los datos convergen, cada destello de luz revela el origen de nuestra propia identidad. Luna-001 no es solo un reflejo; es el comienzo del nuevo horizonte."
    }

    fun generateCharacterBio(name: String, seed: Long): String {
        return "Entidad sintética de grado Aether creada bajo la arquitectura neuronal Nova-X. Modelo $name configurado con semilla criptográfica #$seed. Posee epidermis biónica autorregenerativa, interfaz ocular de análisis espectral y blindaje térmico de grafeno ligero para operaciones en entornos hostiles."
    }

    private fun callGeminiApi(prompt: String, apiKey: String): String {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey")
        val conn = url.openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.setRequestProperty("Content-Type", "application/json")
        conn.doOutput = true
        conn.connectTimeout = 8000
        conn.readTimeout = 8000

        val requestBody = JSONObject()
        val contents = JSONObject()
        val parts = JSONObject()
        parts.put("text", prompt)
        contents.put("parts", org.json.JSONArray().put(parts))
        requestBody.put("contents", org.json.JSONArray().put(contents))

        OutputStreamWriter(conn.outputStream).use { it.write(requestBody.toString()) }

        val response = StringBuilder()
        BufferedReader(InputStreamReader(conn.inputStream)).use { reader ->
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                response.append(line)
            }
        }
        val fullJson = JSONObject(response.toString())
        val candidates = fullJson.getJSONArray("candidates")
        val firstCandidate = candidates.getJSONObject(0)
        val content = firstCandidate.getJSONObject("content")
        val text = content.getJSONArray("parts").getJSONObject(0).getString("text")
        
        // Clean possible markdown code fences
        val cleanText = text.replace("```json", "").replace("```", "").trim()
        return cleanText
    }
}
